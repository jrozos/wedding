<div id="historia" class="section">
    <div class="container">
        <div class="row">
            <div class="title-area">
                <h2>Nuestra historia</h2>
                <div class="separator separator-danger">✻</div>
                <p class="description">We promise you a new look and more importantly, a new attitude. We build that by getting to know you, your needs and creating the best looking clothes.</p>
            </div>
        </div>
    </div>
</div>