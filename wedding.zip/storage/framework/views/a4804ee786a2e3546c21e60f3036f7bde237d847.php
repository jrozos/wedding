<div class="section section-header">
    <div class="parallax filter filter-color-red">
        <div class="image"
            style="background-image: url('img/header-2.jpg')">
        </div>
        <div class="container">
            <div class="content">
                <div class="title-area">
                    <p>Free Demo</p>
                    <h1 class="title-modern">Reserva la fecha</h1>
                    <h3>Nos casamos Octubre 29, 2022</h2>
                    <div class="separator line-separator">♦</div>
                </div>

                <div class="button-get-started">
                    <a href="http://www.creative-tim.com/product/gaia-bootstrap-template" target="_blank" class="btn btn-white btn-fill btn-lg ">
                        Download Demo
                    </a>
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\laragon\www\wedding\resources\views/header/header.blade.php ENDPATH**/ ?>